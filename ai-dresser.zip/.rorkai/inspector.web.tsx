
export function BundleInspector({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
